- 👋 Hi, I’m Mohammed Zuhayr
- 👀 I’m interested in data science
- 🌱 I’m currently learning computer science
- 📫 m.zuhayr2001@gmail.com

<!---
MZuhayr13/MZuhayr13 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
